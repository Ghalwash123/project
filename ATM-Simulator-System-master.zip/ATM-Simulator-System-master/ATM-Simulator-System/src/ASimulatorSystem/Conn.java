package ASimulatorSystem;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;  

public class Conn{
    Connection c;
    Statement s;
    public Conn(){  
        try{  
            Class.forName("org.sqlite.JDBC");  
            c =DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Asus\\OneDrive\\Desktop\\bank.db");    
            s =c.createStatement(); 
           
          
            
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }  
}  
